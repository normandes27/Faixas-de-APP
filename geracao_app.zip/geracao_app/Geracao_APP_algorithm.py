# -*- coding: utf-8 -*-
"""
Caixa_Ferramentas_PRAD_Toolbox
Módulo Determinar APP de margens de cursos d'água e nascentes

Autor: Laboratório de Geoprocessamento ICAT-UFR e 
Laboratório de Geoprocessamento para Aplicações Ambientais - LabGIS FAENG UFMS
Licença: GPLv2 ou posterior
"""

__author__ = 'PRAD_Toolbox_UFR_UFMS'
__date__ = '2025-11-10'
__copyright__ = '(C) 2024 by PRAD_Toolbox_UFR_UFMS'
__revision__ = '$Format:%H$'

import processing

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingMultiStepFeedback,
    QgsProcessingParameterVectorLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterCrs,
    QgsProcessingParameterVectorDestination,
)

class Geracao_APPAlgorithm(QgsProcessingAlgorithm):
    """
    Geração de APP ao redor de rios (linha) e nascentes (ponto),
    com buffers assimétricos para rios e buffer circular para nascentes.
    """

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterVectorLayer(
                'rios',
                'Arquivo Vetorial - Rios (linha)',
                types=[QgsProcessing.TypeVectorLine],
                defaultValue=None
            )
        )

        self.addParameter(
            QgsProcessingParameterVectorLayer(
                'nascentes',
                'Arquivo Vetorial - Nascentes (ponto)',
                types=[QgsProcessing.TypeVectorPoint],
                defaultValue=None
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                'buffer_dist_rios_esq',
                'Distância do Buffer dos Rios - Lado Esquerdo (m)',
                QgsProcessingParameterNumber.Double,
                defaultValue=30
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                'buffer_dist_rios_dir',
                'Distância do Buffer dos Rios - Lado Direito (m)',
                QgsProcessingParameterNumber.Double,
                defaultValue=30
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                'buffer_dist_nascentes',
                'Distância do Buffer das Nascentes (m)',
                QgsProcessingParameterNumber.Double,
                defaultValue=50
            )
        )

        self.addParameter(
            QgsProcessingParameterCrs(
                'crs',
                'Sistema de Referência de Coordenadas (SRC)',
                defaultValue='EPSG:4326'
            )
        )

        self.addParameter(
            QgsProcessingParameterVectorDestination(
                'APPtotal',
                'Buffer Unificado e Dissolvido',
                createByDefault=True,
                defaultValue=None
            )
        )

    def processAlgorithm(self, parameters, context, model_feedback):
        feedback = QgsProcessingMultiStepFeedback(10, model_feedback)
        outputs = {}

        # 1. Reprojetar rios
        alg_params = {
            'INPUT': parameters['rios'],
            'TARGET_CRS': parameters['crs'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['RiosComSRC'] = processing.run(
            'native:reprojectlayer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        # 2. Reprojetar nascentes
        alg_params = {
            'INPUT': parameters['nascentes'],
            'TARGET_CRS': parameters['crs'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['NascentesComSRC'] = processing.run(
            'native:reprojectlayer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # 3. Buffer rios lado direito (distância positiva)
        alg_params = {
            'INPUT': outputs['RiosComSRC']['OUTPUT'],
            'DISTANCE': parameters['buffer_dist_rios_dir'],
            'SEGMENTS': 10,
            'END_CAP_STYLE': 0,
            'JOIN_STYLE': 0,
            'MITER_LIMIT': 2,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferRiosDireito'] = processing.run(
            'native:singlesidedbuffer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # 4. Buffer rios lado esquerdo (distância negativa)
        alg_params = {
            'INPUT': outputs['RiosComSRC']['OUTPUT'],
            'DISTANCE': -1 * parameters['buffer_dist_rios_esq'],
            'SEGMENTS': 10,
            'END_CAP_STYLE': 0,
            'JOIN_STYLE': 0,
            'MITER_LIMIT': 2,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferRiosEsquerdo'] = processing.run(
            'native:singlesidedbuffer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # 5. Unir buffers de rios
        alg_params = {
            'LAYERS': [
                outputs['BufferRiosDireito']['OUTPUT'],
                outputs['BufferRiosEsquerdo']['OUTPUT']
            ],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BuffersRiosUnidos'] = processing.run(
            'native:mergevectorlayers',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # 6. Buffer nascentes
        alg_params = {
            'INPUT': outputs['NascentesComSRC']['OUTPUT'],
            'DISTANCE': parameters['buffer_dist_nascentes'],
            'SEGMENTS': 10,
            'DISSOLVE': False,
            'END_CAP_STYLE': 0,
            'JOIN_STYLE': 0,
            'MITER_LIMIT': 2,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferNascentes'] = processing.run(
            'native:buffer',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # 7. União buffers rios + nascentes
        alg_params = {
            'LAYERS': [
                outputs['BuffersRiosUnidos']['OUTPUT'],
                outputs['BufferNascentes']['OUTPUT']
            ],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['UniaoBuffers'] = processing.run(
            'native:mergevectorlayers',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # 8. Dissolver buffers unidos
        alg_params = {
            'INPUT': outputs['UniaoBuffers']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferUnificadoDissolvido'] = processing.run(
            'native:dissolve',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # 9. Calcular área em hectares
        alg_params = {
            'FIELD_NAME': 'Area_ha',
            'FIELD_TYPE': 0,
            'FIELD_LENGTH': 10,
            'FIELD_PRECISION': 4,
            'NEW_FIELD': True,
            'FORMULA': 'area($geometry)/10000',
            'INPUT': outputs['BufferUnificadoDissolvido']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['BufferComArea'] = processing.run(
            'qgis:fieldcalculator',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # 10. Corrigir geometrias finais
        alg_params = {
            'INPUT': outputs['BufferComArea']['OUTPUT'],
            'OUTPUT': parameters['APPtotal']
        }
        outputs['BufferFinal'] = processing.run(
            'native:fixgeometries',
            alg_params,
            context=context,
            feedback=feedback,
            is_child_algorithm=True
        )

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        return {'APPtotal': outputs['BufferFinal']['OUTPUT']}

    def name(self):
        return 'BufferRiosNascentesUnificado'

    def displayName(self):
        return 'Geração de APP em Rios e Nascentes'

    def group(self):
        return 'Hidrografia'

    def groupIndex(self):
        return 0

    def shortHelpString(self):
        return (r"""<html>
        <div style="font-family: Tahoma; text-align: justify;">
            <p>Algoritmo para gerar áreas de preservação permanente (APP)
               ao redor de rios (linha) e nascentes (ponto), permitindo
               distâncias diferentes para o lado esquerdo e direito dos rios
               e um buffer circular para nascentes. Em seguida, é calculada
               a área em hectares de cada polígono gerado.
              </p>
        </div>
        </html>""")

    def helpUrl(self):
        return 'https://drive.google.com/file/d/1sRmZ1JKqcYo89wcHIpIQMP0Wenjtaawd/view?usp=sharing'

    def createInstance(self):
        return Geracao_APPAlgorithm() 

